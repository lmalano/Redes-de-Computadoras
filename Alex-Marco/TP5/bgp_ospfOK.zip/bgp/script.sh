#!/bin/bash
# Se elimina default gateway
sudo docker exec bgp_h11_1 ip route del default
sudo docker exec bgp_h12_1 ip route del default
sudo docker exec bgp_h13_1 ip route del default
sudo docker exec bgp_h14_1 ip route del default
sudo docker exec bgp_r3_1 ip route del default
sudo docker exec bgp_r4_1 ip route del default
sudo docker exec bgp_r5_1 ip route del default
sudo docker exec bgp_r6_1 ip route del default
sudo docker exec bgp_r7_1 ip route del default
sudo docker exec bgp_r8_1 ip route del default
sudo docker exec bgp_r9_1 ip route del default
sudo docker exec bgp_b1_1 ip route del default
sudo docker exec bgp_b2_1 ip route del default
sudo docker exec bgp_b3_1 ip route del default
sudo docker exec bgp_r3_1 ip -6 route del default
sudo docker exec bgp_r4_1 ip -6 route del default
sudo docker exec bgp_r5_1 ip -6 route del default
sudo docker exec bgp_r6_1 ip -6 route del default
sudo docker exec bgp_r7_1 ip -6 route del default
sudo docker exec bgp_r8_1 ip -6 route del default
sudo docker exec bgp_r9_1 ip -6 route del default
sudo docker exec bgp_b1_1 ip -6 route del default
sudo docker exec bgp_b2_1 ip -6 route del default
sudo docker exec bgp_b3_1 ip -6 route del default
sudo docker exec bgp_h11_1 ip -6 route del default
sudo docker exec bgp_h12_1 ip -6 route del default
sudo docker exec bgp_h13_1 ip -6 route del default
sudo docker exec bgp_h14_1 ip -6 route del default
# Se agrega default gateway a los hosts
sudo docker exec bgp_h11_1 ip -6 route add default via 2001:a:aaaa:5::2
sudo docker exec bgp_h12_1 ip -6 route add default via 2001:a:bbbb:5::2
sudo docker exec bgp_h13_1 ip -6 route add default via 2001:a:aaaa:6::2
sudo docker exec bgp_h14_1 ip -6 route add default via 2001:a:bbbb:6::2

# Se agrega como default gateway a los routers de borde
sudo docker exec bgp_r3_1 ip -6 route add default via 2001:a:aaaa:1::2
sudo docker exec bgp_r4_1 ip -6 route add default via 2001:a:bbbb:1::2
sudo docker exec bgp_r5_1 ip -6 route add default via 2001:a:aaaa:2::2
sudo docker exec bgp_r6_1 ip -6 route add default via 2001:a:bbbb:2::2
sudo docker exec bgp_r7_1 ip -6 route add default via 2001:a:aaaa:3::2
sudo docker exec bgp_r8_1 ip -6 route add default via 2001:a:bbbb:3::2
sudo docker exec bgp_r9_1 ip -6 route add default via 2001:a:cccc:1::2
