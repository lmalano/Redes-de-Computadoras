#!/bin/sh -e
#Se elimina el default gateway
ip -6 route del default
