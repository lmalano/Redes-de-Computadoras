#!/bin/bash

ip netns exec ns2.$1 ping6 -c 3 2001:aaaa:dddd:1::1
#ejecutar -->source ping.sh param(1 al 5)
echo
ip netns exec ns2.$1 ping6 -c 3 2001:aaaa:dddd:1::2