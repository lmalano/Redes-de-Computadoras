!#/bin/bash

echo Script para probar namespace y bridge

sleep 2s
#creo namespace
ip netns add ns1.1
#creo el veth peer
ip link add nsA type veth peer name brA
#le asigno un extremo el veth peer al ns1.1
ip link set nsA netns ns1.1
#le asigno un extremo el veth peer al bridge
brctl addbr bridge
#agrego interfaz al bridge
brctl addif bridge brA
brctl addif bridge enp3s0f2
#levanto las interfaces del ns1.1
ip netns exec ns1.1 ip link set up dev lo
ip netns exec ns1.1 ip link set up dev nsA
#asigno IPv6 tanto al namespace como al bridge
ip netns exec ns1.1 ip addr add 2001:a:1::10/64 dev nsA
ip -6 address add 2001:a:1::5/64 dev bridge
#levanto el bridge
ip link set up bridge
#levanto la interfaz del bridge
ip link set brA up
#muestro las configuraciones
ip netns exec ns1.1 ip -6 addr
ip netns exec ns1.1 ip link
show bridge
ip addr

